package com.job.match.matchajob.classes

class candidato (_nome: String){
    var nome:String = ""


    init {
        nome = _nome;
    }

}