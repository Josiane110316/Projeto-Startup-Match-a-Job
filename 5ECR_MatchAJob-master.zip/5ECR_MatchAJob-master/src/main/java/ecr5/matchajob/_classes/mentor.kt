package com.job.match.matchajob.classes

class mentor (_nome: String){
    var nome:String = ""


    init {
        nome = _nome;
    }

}