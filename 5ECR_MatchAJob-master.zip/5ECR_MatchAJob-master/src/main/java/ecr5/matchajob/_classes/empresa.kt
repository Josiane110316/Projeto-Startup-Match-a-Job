package com.job.match.matchajob.classes

class empresa (_nome: String){
    var nome:String = ""


    init {
        nome = _nome;
    }
}