Usu�rios para testes
----

Devido ao fato da aplica��o possuir 3 tipos de contas e a implanta��o com um banco de dados ainda n�o ter sido feita, a valida��o por tipo de usu�rio � feita atrav�s do texto inserido no campo de login (Email). Para navegar siga o exemplo abaixo:

| Username (E-mail)      | Tipo de login |
|  -----: | -----:|
| empresa  | empresa |
| candidato     |   candidato |
| mentor      |    mentor |

<b>OBS:</b> O campo n�o � key sensitive.